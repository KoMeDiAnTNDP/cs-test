enum LoadingStatus {
  idle,
  loading,
  success,
  failed
}