import 'package:cs_test/pages/login/login_form.dart';
import 'package:cs_test/utilities/constants.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:cs_test/pages/login/login_view_model.dart';
import 'package:cs_test/state.dart';
import 'package:cs_test/models/models.dart';

class LoginPage extends StatelessWidget {
  LoginPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StoreConnector<GlobalAppState, LoginViewModel>(
        distinct: true,
        onDidChange: (LoginViewModel viewModel) {
          if (viewModel.authState.loadingStatus == LoadingStatus.success) {
            viewModel.dispatchNavigateToHome(context);
          }
        },
        converter: (Store<GlobalAppState> store) => LoginViewModel.create(store),
        builder: (BuildContext context, LoginViewModel viewModel) => buildContent(context, viewModel)
      )
    );
  }

  Widget buildContent(BuildContext context, LoginViewModel viewModel) =>
    SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            _buildHeader(context, viewModel),
            LoginFormWidget(viewModel, key: Key('login-form'))
          ],
        ),
      )
    );

  Widget _buildHeader(BuildContext context, LoginViewModel viewModel) => SafeArea(
    child: Column(
      children: [Padding(
        padding: const EdgeInsets.only(top: 40, bottom: 20),
        child: Container(
          height: 75,
          child: Image.asset('assets/logo/logo-icon.png', fit: BoxFit.cover)
        )
      ),
      Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Text(
          Constants.APP_NAME,
          style: TextStyle(
            fontSize: 22,
            color: Theme.of(context).accentColor
          )
        ),
      )]
    )
  );
}