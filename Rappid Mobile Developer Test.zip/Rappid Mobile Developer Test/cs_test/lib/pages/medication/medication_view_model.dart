import 'package:redux/redux.dart';
import 'package:cs_test/state.dart';

// TODO: Create Medication View Model
class MedicationViewModel {
  MedicationViewModel();

  factory MedicationViewModel.create(Store<GlobalAppState> store) => MedicationViewModel();
}