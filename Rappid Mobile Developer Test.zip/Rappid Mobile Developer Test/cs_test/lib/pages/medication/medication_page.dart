import 'package:redux/redux.dart';
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:cs_test/pages/medication/medication_view_model.dart';
import 'package:cs_test/state.dart';

// TODO: Implement Medications Page
class MedicationPage extends StatelessWidget{
  final TabController tabController;
  MedicationPage({Key key, this.tabController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StoreConnector<GlobalAppState, MedicationViewModel>(
        distinct: true,
        converter: (Store<GlobalAppState> store) => MedicationViewModel.create(store),
        onInitialBuild: (MedicationViewModel viewModel) {
          //
        },
        builder: (BuildContext context, MedicationViewModel viewModel) => buildContent(context, viewModel)
    );
  }

  Widget buildContent(BuildContext context, MedicationViewModel viewModel) => 
    TabBarView(
      physics: NeverScrollableScrollPhysics(),
      controller: tabController,
      children: <Widget>[
        buildTodaysContent(context, viewModel),
        buildActiveContent(context, viewModel),
        buildExpiredContent(context, viewModel)
      ],
    );

  Widget buildTodaysContent(BuildContext context, MedicationViewModel viewModel) => 
    Container(
      alignment: Alignment.center,
      child: Text("Today's Medications", style: TextStyle())
    );
    
  Widget buildActiveContent(BuildContext context, MedicationViewModel viewModel) => 
    Container(
      alignment: Alignment.center,
      child: Text("All Active Medications")
    );
    
  Widget buildExpiredContent(BuildContext context, MedicationViewModel viewModel) => 
    Container(
      alignment: Alignment.center,
      child: Text("Expired Medications"),
    );
}