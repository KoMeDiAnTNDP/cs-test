import 'package:cs_test/providers/providers.dart' show MedicationAPIProvider;

class MedicationAPI {
  final MedicationAPIProvider _apiProvider;
  MedicationAPI(this._apiProvider);
  
  // TODO: Implement Medication API Interface
}