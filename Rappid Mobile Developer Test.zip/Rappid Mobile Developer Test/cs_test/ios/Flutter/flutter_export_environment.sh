#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=E:\dev\flutter\flutter"
export "FLUTTER_APPLICATION_PATH=E:\dev\work\rappid\cs\cs_test\cs_test"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build\ios"
export "FLUTTER_FRAMEWORK_DIR=E:\dev\flutter\flutter\bin\cache\artifacts\engine\ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
