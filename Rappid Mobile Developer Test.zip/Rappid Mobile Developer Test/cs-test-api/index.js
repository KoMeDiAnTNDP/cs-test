require('ts-node/register');
require('./src/index');